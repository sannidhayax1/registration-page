document.getElementById('registrationForm').addEventListener('submit', function (e) {
    e.preventDefault();
  
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const gender = document.getElementById('gender').value;
    const dob = document.getElementById('dob').value;
  
    fetch('http://localhost:5002/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, email, password, gender, dob })
    })
    .then(response => response.json())
    .then(data => {
      alert(data.message);
      if (data.message === 'User registered successfully!') {
        document.getElementById('registrationForm').reset();
      }
    })
    .catch(error => {
      alert('Error: ' + error.message);
    });
  });
  
  document.getElementById('fetchUsersBtn').addEventListener('click', function () {
      fetch('http://localhost:5002/users')
        .then(response => response.json())
        .then(users => {
          const tableBody = document.getElementById('usersTable').getElementsByTagName('tbody')[0];
          tableBody.innerHTML = ''; 
  
          users.forEach(user => {
            const row = tableBody.insertRow();
            row.insertCell(0).textContent = user.username;
            row.insertCell(1).textContent = user.email;
            row.insertCell(2).textContent = user.gender;
            row.insertCell(3).textContent = user.dob;
          });
        })
        .catch(error => {
          alert('Error fetching users: ' + error.message);
        });
  });
  