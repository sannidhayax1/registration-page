const express = require('express');
const cors = require('cors');  
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(cors());

app.use(bodyParser.json());

const usersFilePath = path.join(__dirname, 'users.json');

function readUsersData() {
  if (!fs.existsSync(usersFilePath)) {
    return []; 
  }
  const data = fs.readFileSync(usersFilePath);
  return JSON.parse(data);
}

function writeUsersData(users) {
  fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
}
app.post('/register', (req, res) => {
  const { username, email, password, gender, dob } = req.body;

  if (!username || !email || !password || !gender || !dob) {
    return res.status(400).json({ message: 'All fields are required!' });
  }
  const users = readUsersData();
  const userExists = users.find(user => user.email === email);
  if (userExists) {
    return res.status(400).json({ message: 'User already exists with this email' });
  }

  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) {
      return res.status(500).json({ message: 'Error hashing password' });
    }

    users.push({
      username,
      email,
      password: hashedPassword,
      gender,
      dob
    });

    writeUsersData(users);

    return res.status(201).json({ message: 'User registered successfully!' });
  });
});
app.get('/users', (req, res) => {
  const users = readUsersData();
  res.status(200).json(users);
});
const PORT = process.env.PORT || 5002;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
